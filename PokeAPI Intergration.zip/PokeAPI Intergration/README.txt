For this test I looked into making an Poke API that can pull data from the poke API and display it real time in an HTML website


For this I looked into using Async Functions with fetch and await for making it work

For the types we need to do some extra steps to pull the information as a pokemon can have more than one type (an array)

I looked at doing some extra steps to capitalize the words aswell for everything, should the pokemon not be found an error message appears 

Alongside this we display is the pokemon shiny if the checkbox has been clicked to add something extra!

This can work with either the pokemon name or number eg 1 or bulbasaw


Ive added some basic formatting with bootstrap aswell to make it look a bit nicer

PS If your reading this what is your favourite pokemon>? Mines Genesect :)